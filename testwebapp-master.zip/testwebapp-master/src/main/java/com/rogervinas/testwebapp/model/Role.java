package com.rogervinas.testwebapp.model;

public abstract class Role extends ActiveRecord<Role>
{
	public Role(String id) {
		super(id);
	}	
}
