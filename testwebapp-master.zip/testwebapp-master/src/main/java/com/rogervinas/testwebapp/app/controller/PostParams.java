package com.rogervinas.testwebapp.app.controller;

import java.util.Properties;

public class PostParams extends Properties
{
	private static final long serialVersionUID = 2847447056490733217L;
}
