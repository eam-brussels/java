package com.rogervinas.testwebapp.app.view;

import java.util.HashMap;

public class TemplateValues extends HashMap<String,String>
{
	private static final long serialVersionUID = 1184882210669721539L;
}
